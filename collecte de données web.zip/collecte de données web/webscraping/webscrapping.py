# -*- coding: utf-8 -*-
"""
Scraper des restaurants étoilés Michelin France / Monaco 2025

Installer les modules nécessaires :
pip install requests beautifulsoup4 pandas folium tqdm geopy flask matplotlib branca
"""

# --- Import des modules externes ---
import requests                       # Pour envoyer des requêtes HTTP
from bs4 import BeautifulSoup          # Pour parser le HTML
import pandas as pd                    # Pour manipuler les tableaux de données
import folium                          # Pour créer une carte interactive
import webbrowser                      # Pour ouvrir automatiquement une page web
import time                            # Pour mettre des pauses dans le code
import random                          # Pour ajouter du hasard (ex : décalage sur carte)
from tqdm import tqdm                  # Pour afficher une barre de progression
from geopy.geocoders import Nominatim  # Pour convertir une ville en coordonnées GPS
from flask import Flask, render_template, url_for  # Pour créer une interface web
import os                              # Pour gérer les fichiers et dossiers
import matplotlib                      # Pour générer des graphiques
matplotlib.use('Agg')                  # Mode non interactif (utile pour Flask)
import matplotlib.pyplot as plt        # Pour tracer des graphiques
import branca.element                  # Outil complémentaire pour Folium

# ------------------------------------------------------------
# 1. Récupération des coordonnées GPS d'un restaurant Wikipédia
# ------------------------------------------------------------
def scrape_restaurant_coordinates(url, session):
    """
    Ouvre la page Wikipédia du restaurant pour récupérer sa latitude/longitude.
    Retourne (lat, lon) si trouvées, sinon (None, None).
    """
    try:
        r = session.get(url, timeout=10)
        r.raise_for_status()  # vérifie que la page est accessible
        soup = BeautifulSoup(r.text, "html.parser")
        # On cherche l'élément contenant les coordonnées
        coord = soup.select_one('a.mw-kartographer-maplink')
        if coord and coord.has_attr('data-lat') and coord.has_attr('data-lon'):
            return coord.get('data-lat'), coord.get('data-lon')
    except requests.exceptions.RequestException:
        # Gère uniquement les erreurs de réseau (timeout, 404, etc.)
        pass

    return None, None


# ------------------------------------------------------------
# 2. Géocodage d'une localité (ville → latitude/longitude)
# ------------------------------------------------------------
def geocode_localite(localite, geolocator):
    """
    Si un restaurant n’a pas de coordonnées GPS, 
    cette fonction utilise l’API de geopy pour retrouver la ville.
    """
    try:
        # Cas particulier : Monaco n’est pas en France
        query = localite if "monaco" in localite.lower() else f"{localite}, France"
        loc = geolocator.geocode(query, timeout=10)
        if loc:
            return loc.latitude, loc.longitude
    except:
        pass
    return None, None


# ------------------------------------------------------------
# 3. Scraping principal de la page Wikipédia + géocodage
# ------------------------------------------------------------
def run_scraping_and_geocoding(session):
    """
    - Télécharge la page Wikipédia du Guide Michelin.
    - Extrait les tableaux des restaurants 2 et 3 étoiles.
    - Tente de récupérer ou calculer les coordonnées GPS.
    - Retourne un DataFrame Pandas + statistiques globales.
    """
    url = "https://fr.wikipedia.org/wiki/Liste_des_restaurants_deux_et_trois_étoiles_du_Guide_Michelin"
    geolocator = Nominatim(user_agent="michelin_scraper")

    print(f"Connexion à : {url}")
    r = session.get(url)
    soup = BeautifulSoup(r.text, "lxml")

    liste_restaurants = []
    titres = [h for h in soup.find_all("h3") if h.text.strip().startswith("France et Monaco")]

    # --- Scraping des 3 étoiles ---
    if titres:
        table3 = titres[0].find_next('table', class_='wikitable')
        print("Scraping 3 étoiles...")
        for row in tqdm(table3.find_all('tr')[1:]):  # ignore la ligne d’en-tête
            cells = [c.text.strip() for c in row.find_all('td')]
            if len(cells) < 6:
                continue
            
            # Cherche un lien dans la cellule du restaurant (index 2) ou de la localité (index 3)
            restaurant_cell, localite_cell = row.find_all('td')[2:4]
            lien = restaurant_cell.find('a', href=True)
            
            # Cas particulié
            if cells[2] == "Le Louis XV - Alain Ducasse à l'Hôtel de Paris":
                lien = localite_cell.find('a', href=True)  

            lat, lon = (None, None)
            if lien:
                # Accès à la page Wikipédia du restaurant
                lat, lon = scrape_restaurant_coordinates("https://fr.wikipedia.org" + lien['href'], session)
                time.sleep(0.05)  # petite pause pour ne pas surcharger le site

            # Ajout d’une ligne dans la liste finale
            liste_restaurants.append({
                'Chef': cells[1],
                'Restaurant': cells[2],
                'Localite': cells[3],
                'Departement': cells[4],
                'Region': cells[5],
                'Etoiles': 3,
                'Latitude': lat,
                'Longitude': lon
            })

    # --- Scraping des 2 étoiles ---
    if len(titres) > 1:
        table2 = titres[1].find_next('table', class_='wikitable')
        print("Scraping 2 étoiles...")
        for row in tqdm(table2.find_all('tr')[1:]):
            cells = [c.text.strip() for c in row.find_all('td')]
            if len(cells) < 5:
                continue

            # Cherche un lien dans la cellule du restaurant (index 1) ou de la localité (index 2)
            restaurant_cell, localite_cell = row.find_all('td')[1:3]
            lien = restaurant_cell.find('a', href=True) or localite_cell.find('a', href=True)

            lat, lon = (None, None)
            if lien:
                lat, lon = scrape_restaurant_coordinates("https://fr.wikipedia.org" + lien['href'], session)
                time.sleep(0.05)
            liste_restaurants.append({
                'Chef': cells[0],
                'Restaurant': cells[1],
                'Localite': cells[2],
                'Departement': cells[3],
                'Region': cells[4],
                'Etoiles': 2,
                'Latitude': lat,
                'Longitude': lon
            })

    # --- Création du DataFrame ---
    df = pd.DataFrame(liste_restaurants)
    df['Latitude'] = pd.to_numeric(df['Latitude'], errors='coerce')
    df['Longitude'] = pd.to_numeric(df['Longitude'], errors='coerce')

    # --- Géocodage des localités manquantes ---
    print("Géocodage des localités manquantes...")
    localites = df[df['Latitude'].isna()]['Localite'].unique()
    coords_cache = {}

    for loc in tqdm(localites):
        lat, lon = geocode_localite(loc, geolocator)
        coords_cache[loc] = (lat, lon)
        time.sleep(0.2)  # pause pour ne pas saturer le service de géocodage

    # Ajout des coordonnées géocodées dans le DataFrame
    for i, row in df.iterrows():
        if pd.isna(row['Latitude']):
            lat, lon = coords_cache.get(row['Localite'], (None, None))
            df.at[i, 'Latitude'], df.at[i, 'Longitude'] = lat, lon

    # --- Nettoyage des données ---
    # Si la ville ou le département contient "Monaco", on force la région "Monaco"
    is_monaco = df['Localite'].str.contains("Monaco", case=False, na=False) | df['Departement'].str.contains("Monaco", case=False, na=False)
    df.loc[is_monaco, 'Region'] = "Monaco"
    df['Region'] = df['Region'].replace('', None)
    df['Region'] = df['Region'].fillna("Région inconnue")

    # --- Statistiques simples ---
    df = df.dropna(subset=['Latitude', 'Longitude'])
    stats = {
        'total': len(df),
        'count_3': (df['Etoiles'] == 3).sum(),
        'count_2': (df['Etoiles'] == 2).sum()
    }

    return df, stats


# ------------------------------------------------------------
# 4. Génération du graphique (restaurants par région)
# ------------------------------------------------------------
def generate_chart(df, filename):
    """
    Crée un graphique montrant le nombre de restaurants 2 et 3 étoiles par région.
    """
    print("Génération du graphique...")

    data = df.groupby('Region')['Etoiles'].value_counts().unstack(fill_value=0)
    data['Total'] = data.sum(axis=1)
    data = data.sort_values('Total', ascending=False)

    plt.style.use('fivethirtyeight')
    fig, ax = plt.subplots(figsize=(15, 10))

    # Barres empilées 2 étoiles / 3 étoiles
    ax.bar(data.index, data.get(2, 0), color='orange', label='2 étoiles')
    ax.bar(data.index, data.get(3, 0), bottom=data.get(2, 0), color='green', label='3 étoiles')

    ax.set_title('Restaurants étoilés par région', fontsize=20, fontweight='bold')
    ax.set_ylabel('Nombre de restaurants', fontsize=14)
    ax.tick_params(axis='x', rotation=60, labelsize=11)
    ax.legend(fontsize=12)

    # Ajout des étiquettes sur les barres (si assez grandes)
    deux_etoiles = data.get(2, 0)
    trois_etoiles = data.get(3, 0)
    for i, (val2, val3) in enumerate(zip(deux_etoiles, trois_etoiles)):
        if val2 > 3:
            ax.text(i, val2 / 2, val2, ha='center', va='center', color='white', fontsize=10, fontweight='bold')
        if val3 > 0:
            ax.text(i, val2 + val3 / 2, val3, ha='center', va='center', color='white', fontsize=10, fontweight='bold')

    # Sauvegarde dans le dossier static/
    os.makedirs('static', exist_ok=True)
    path = os.path.join('static', filename)
    plt.tight_layout(pad=1.5)
    plt.savefig(path, dpi=200)
    plt.close(fig)
    print("Graphique enregistré.")

    return filename


# ------------------------------------------------------------
# 5. Génération de la carte interactive (Folium)
# ------------------------------------------------------------
def generate_map(df, filename):
    """
    Crée une carte interactive Folium avec un marqueur par restaurant.
    """
    print("Création de la carte...")

    carte = folium.Map(location=[46.6, 2.5], zoom_start=6, tiles='CartoDB positron')
    coord_counts = {}  # évite que deux marqueurs soient superposés

    for _, row in df.iterrows():
        lat, lon = row['Latitude'], row['Longitude']
        coords = (lat, lon)

        # Si un point existe déjà ici, on décale légèrement pour éviter le chevauchement
        if coords in coord_counts:
            coord_counts[coords] += 1
            lat += random.uniform(-0.0003, 0.0003)
            lon += random.uniform(-0.0003, 0.0003)
        else:
            coord_counts[coords] = 1

        # Couleur différente selon le nombre d’étoiles
        color = 'green' if row['Etoiles'] == 3 else 'orange'
        popup = f"<b>{row['Restaurant']}</b><br>Chef : {row['Chef']}<br>{'⭐' * row['Etoiles']}"

        folium.Marker(
            [lat, lon],
            popup=popup,
            tooltip=row['Restaurant'],
            icon=folium.Icon(color=color, icon='star', prefix='fa')
        ).add_to(carte)

    # Sauvegarde de la carte
    os.makedirs('static', exist_ok=True)
    path = os.path.join('static', filename)
    carte.save(path)
    print("Carte enregistrée.")

    return filename


# ------------------------------------------------------------
# 6. Exécution principale et lancement de Flask
# ------------------------------------------------------------
# Création d'une session web avec un "User-Agent" pour éviter d'être bloqué
session = requests.Session()
session.headers.update({'User-Agent': 'Mozilla/5.0'})

print("Scraping et génération des fichiers...")
df, stats = run_scraping_and_geocoding(session)

# Génération de la carte et du graphique
map_file = generate_map(df, "carte_restaurants.html")
chart_file = generate_chart(df, "graph_regions.png")

# Application web Flask
app = Flask(__name__)

@app.route('/')
def index():
    """
    Affiche la page principale avec la carte et le graphique.
    """
    return render_template(
        'index.html',
        stats=stats,
        map_file=url_for('static', filename=map_file),
        chart_file=url_for('static', filename=chart_file)
    )

# Lancement du serveur local
if __name__ == "__main__":
    print("Serveur en cours de lancement sur http://127.0.0.1:5000")
    webbrowser.open('http://127.0.0.1:5000')
    app.run(debug=False)
