import requests
import pandas as pd
import folium
from folium.plugins import MarkerCluster
import branca.colormap as cm
import warnings
import webbrowser
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import base64
from io import BytesIO
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import json # Nécessaire pour la nouvelle fonction de rapport
import re # Nécessaire pour l'injection JS dans la carte

# --- CONFIGURATION ---
URL_BASE = "https://opendata.paris.fr/api/explore/v2.1/catalog/datasets/velib-disponibilite-en-temps-reel/records"
warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid")
MAX_WORKERS = 10

# --- PARTIE 1 : RÉCUPÉRATION DE TOUTES LES DONNÉES (Inchangée) ---

def fetch_page(offset, limit=100):
    """Récupère une seule page de résultats."""
    try:
        r = requests.get(URL_BASE, params={"limit": limit, "offset": offset}, timeout=15)
        r.raise_for_status()
        return r.json().get("results", [])
    except Exception as e:
        print(f"Erreur récupération offset {offset}: {e}")
        return []

def get_all_stations_fast():
    """Récupère toutes les stations en parallèle."""
    try:
        resp = requests.get(URL_BASE, params={"limit": 1}, timeout=15)
        resp.raise_for_status()
        total = resp.json().get("total_count", 0)
    except Exception as e:
        print(f"Erreur récupération total : {e}")
        return pd.DataFrame()

    if total == 0:
        print("Aucune station trouvée.")
        return pd.DataFrame()
        
    print(f"Total stations à récupérer : {total}")
    limit = 100
    offsets = list(range(0, total, limit))
    all_records = []

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(fetch_page, off, limit): off for off in offsets}
        for future in as_completed(futures):
            records = future.result()
            all_records.extend(records)
            print(f"Récupéré {len(all_records)} / {total} stations", end="\r")
    
    print("\nRécupération terminée.")
    df = pd.DataFrame(all_records)
    if df.empty:
        return df

    def extract_coords(geo):
        if isinstance(geo, dict):
            return pd.Series([geo.get("lat"), geo.get("lon")])
        if isinstance(geo, (list, tuple)) and len(geo) == 2:
            return pd.Series([geo[1], geo[0]]) # Attention, parfois [lon, lat]
        return pd.Series([None, None])

    df[['lat', 'lon']] = df['coordonnees_geo'].apply(extract_coords)

    # Assurer que 'lat' et 'lon' sont bien numériques pour les calculs de moyenne
    df['lat'] = pd.to_numeric(df['lat'], errors='coerce')
    df['lon'] = pd.to_numeric(df['lon'], errors='coerce')

    for col in ["capacity", "numbikesavailable", "numdocksavailable", "ebike", "mechanical"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)
    
    df["nom_arrondissement_communes"] = df["nom_arrondissement_communes"].fillna("Inconnu")

    return df

# --- PARTIE 2 : ANALYSE DES DONNÉES (Inchangée) ---

def analyser_et_supprimer_doublons(df):
    """Nettoie le DataFrame des doublons."""
    nb_initial = len(df)
    df_clean = df.drop_duplicates(subset=["stationcode"], keep="first")
    nb_final = len(df_clean)
    print(f"\nNettoyage doublons : {nb_initial} -> {nb_final} stations ({nb_initial - nb_final} supprimés)")
    return df_clean

def calculer_score_equilibre(df):
    """Ajoute les colonnes de score nécessaires pour la carte."""
    print("Calcul des scores d'équilibre...")
    df = df.copy()
    capacity_safe = df["capacity"].replace(0, np.nan)
    numbikes_safe = df["numbikesavailable"].replace(0, np.nan)
    
    df["taux_velos"] = (df["numbikesavailable"] / capacity_safe).fillna(0).clip(0, 1)
    df["taux_docks"] = (df["numdocksavailable"] / capacity_safe).fillna(0).clip(0, 1)
    df["pct_elec"] = (df["ebike"] / numbikes_safe).fillna(0.5).clip(0, 1) # 0.5 (neutre) si 0 vélos
    df["score_diversite"] = 1 - abs(df["pct_elec"] - 0.5) * 2
    df["score_velos_optimal"] = (1 - abs(df["taux_velos"] - 0.3) / 0.7).clip(0, 1)
    df["score_docks_optimal"] = (1 - abs(df["taux_docks"] - 0.3) / 0.7).clip(0, 1)
    
    df["score_equilibre"] = (
        df["score_velos_optimal"] * 0.3 +
        df["score_docks_optimal"] * 0.3 +
        df["score_diversite"] * 0.4
    ) * 100
    
    return df

# --- PARTIE 3 : CARTE FOLIUM (MODIFIÉE AVEC INJECTION JS) ---

def creer_carte_clusters_communes(df):
    """
    Crée une carte Folium avec clusters par commune, popups détaillés
    ET info-bulles au survol.
    Injecte également une fonction JS pour le contrôle externe.
    """
    print("Génération de la carte interactive...")
    m = folium.Map(location=[48.8566, 2.3522], zoom_start=11.5) 

    for commune, group in df.groupby("nom_arrondissement_communes"):
        cluster = MarkerCluster(name=commune).add_to(m)
        
        for _, row in group.iterrows():
            if pd.isna(row["lat"]) or pd.isna(row["lon"]): 
                continue
            
            nb_elec = int(row.get("ebike", 0))
            nb_meca = int(row.get("mechanical", 0))
            total_dispo = int(row.get("numbikesavailable", 0))
            capacite = int(row.get('capacity', 0))
            nom_station = row.get('name', 'Station')
            
            renting = "✅ Oui" if row.get('is_renting') == 'OUI' else "❌ Non"
            returning = "✅ Oui" if row.get('is_returning') == 'OUI' else "❌ Non"
            installed = "✅ Oui" if row.get('is_installed') == 'OUI' else "❌ Non"
            
            try:
                update_time = pd.to_datetime(row.get('duedate')).strftime('%d/%m/%Y %H:%M')
            except:
                update_time = row.get('duedate', 'N/A')

            popup_html = f"""
            <div style='font-family: Arial, sans-serif; width: 280px;'>
            <h4 style='margin:0; padding:3px 5px; background-color:#337ab7; color:white; border-radius: 3px 3px 0 0;'>
                {nom_station}
            </h4>
            <ul style='list-style-type:none; padding-left:5px; margin-top:5px; margin-bottom: 5px; font-size: 0.9em;'>
                <li><b>Commune:</b> {row.get('nom_arrondissement_communes', 'N/A')}</li>
                <li><b>Code Station:</b> {row.get('stationcode', 'N/A')}</li>
            </ul>
            <hr style='margin: 5px 0;'>
            <b style='padding-left:5px; font-size: 0.95em;'>Disponibilité:</b>
            <ul style='list-style-type:none; padding-left:5px; margin-top:5px; margin-bottom: 5px; font-size: 0.9em;'>
                <li>⚡ <b>Électriques:</b> {nb_elec}</li>
                <li>🔧 <b>Mécaniques:</b> {nb_meca}</li>
                <li>🅿️ <b>Docks libres:</b> {int(row.get('numdocksavailable', 0))}</li>
                <li>📊 <b>Total Vélos:</b> {total_dispo} / {capacite} (capacité)</li>
            </ul>
            <hr style='margin: 5px 0;'>
            <b style='padding-left:5px; font-size: 0.95em;'>Statut Station:</b>
            <ul style='list-style-type:none; padding-left:5px; margin-top:5px; margin-bottom: 5px; font-size: 0.9em;'>
                <li><b>Installée:</b> {installed}</li>
                <li><b>Location:</b> {renting}</li>
                <li><b>Retour:</b> {returning}</li>
            </ul>
            <hr style='margin: 5px 0;'>
            <div style='font-size: 0.8em; color: #555; padding: 0 5px 5px 5px;'>
                <i>Score Équilibre: {row.get('score_equilibre', 0):.0f}/100</i><br>
                <i>Dernière màj: {update_time}</i>
            </div>
            </div>
            """

            score = row.get('score_equilibre', 0)
            if score >= 70: color = "green"
            elif score >= 40: color = "orange"
            else: color = "red"
            
            pct_elec = row.get('pct_elec', 0)
            if pct_elec > 0.6: fill_color = "#4169E1"
            elif pct_elec < 0.4: fill_color = "#FFD700"
            else: fill_color = "#999999"
            
            tooltip_text = f"{nom_station} : {total_dispo} / {capacite}"
            
            folium.CircleMarker(
                location=[row["lat"], row["lon"]],
                radius=6, 
                color=color, 
                weight=2, 
                fill=True,
                fill_color=fill_color, 
                fill_opacity=0.8, 
                popup=folium.Popup(popup_html, max_width=300), 
                tooltip=tooltip_text 
            ).add_to(cluster)
    
    folium.LayerControl(collapsed=True).add_to(m)

    legend_html = """
    <div style="
        position: fixed; bottom: 30px; left: 30px; width: 280px; 
        background-color: white; border:2px solid grey; border-radius:10px; 
        padding:12px; font-size:13px; z-index:9999;
        box-shadow: 3px 3px 10px rgba(0,0,0,0.3);
    ">
    <b>Légende</b> (Survolez pour le nom, cliquez pour les détails)<br>
    <hr style='margin: 5px 0;'>
    <b>🎯 Score d'équilibre (Bordure) :</b><br>
    <i style="background:white;width:15px;height:15px;border-radius:50%;display:inline-block;margin-right:5px;border:3px solid green;"></i> Score ≥70 (excellent)<br>
    <i style="background:white;width:15px;height:15px;border-radius:50%;display:inline-block;margin-right:5px;border:3px solid orange;"></i> Score 40-70 (moyen)<br>
    <i style="background:white;width:15px;height:15px;border-radius:50%;display:inline-block;margin-right:5px;border:3px solid red;"></i> Score <40 (déséquilibré)<br>
    <br>
    <b>🚲 Type de vélos (Remplissage) :</b><br>
    <i style="background:#4169E1;width:15px;height:15px;border-radius:50%;display:inline-block;margin-right:5px;border:2px solid #555;"></i> Majorité électriques (>60%)<br>
    <i style="background:#FFD700;width:15px;height:15px;border-radius:50%;display:inline-block;margin-right:5px;border:2px solid #555;"></i> Majorité mécaniques (<40%)<br>
    <i style="background:#999;width:15px;height:15px;border-radius:50%;display:inline-block;margin-right:5px;border:2px solid #555;"></i> Mix équilibré (40-60%)<br>
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))
    
    file = "rapport_carte_complete.html"
    m.save(file)
    print(f"Carte complète générée : {file}")

    # --- AJOUT : Injection de la fonction de contrôle JS ---
    try:
        with open(file, 'r', encoding='utf-8') as f:
            map_html = f.read()

        # 1. Trouver le nom de la variable map (ex: "var map_... = L.map(...)")
        match = re.search(r'var (map_[a-zA-Z0-9_]+) = L\.map', map_html)
        
        if match:
            map_variable_name = match.group(1)
            
            # 2. Créer la fonction JS qui utilise cette variable
            js_function = f"""
            <script>
                function setMapView(lat, lon, zoom) {{
                    try {{
                        {map_variable_name}.setView([lat, lon], zoom);
                    }} catch(e) {{
                        console.error("Erreur setMapView:", e);
                    }}
                }}
            </script>
            """
            
            # 3. Insérer la fonction à la fin du <body>
            map_html = map_html.replace('</body>', js_function + '</body>')
            
            with open(file, 'w', encoding='utf-8') as f:
                f.write(map_html)
            print(f"Fonction JS 'setMapView' injectée dans {file} (map variable: {map_variable_name})")
        else:
            print("AVERTISSEMENT: Impossible de trouver la variable map pour l'injection JS.")
            
    except Exception as e:
        print(f"Erreur lors de l'injection JS : {e}")
    # --- FIN DE L'AJOUT ---

    return file

# --- PARTIE 4 : VOS GRAPHIQUES (par Commune) (Inchangés) ---

def plot_to_base64(plt):
    """Convertit un plot Matplotlib en image base64 pour l'HTML."""
    img_data = BytesIO()
    plt.savefig(img_data, format='png', bbox_inches='tight')
    img_data.seek(0)
    base64_string = base64.b64encode(img_data.read()).decode('utf-8')
    plt.close()
    return f"data:image/png;base64,{base64_string}"

def creer_graph_dispo_moyen(df_agg):
    """(Req b) Graphique comparant le taux de disponibilité moyen par communes"""
    print("Génération graphique (b) Taux dispo moyen...")
    if df_agg.empty: return ""
    
    data = df_agg.nlargest(30, 'taux_dispo_moyen').sort_values('taux_dispo_moyen', ascending=False)
    
    plt.figure(figsize=(10, 8))
    ax = sns.barplot(
        data=data,
        x="taux_dispo_moyen",
        y="nom_arrondissement_communes",
        palette="viridis"
    )
    ax.set_title("Taux de disponibilité moyen (Top 30 Communes)", fontsize=16)
    ax.set_xlabel("Taux de disponibilité (Vélos / Capacité)", fontsize=12)
    ax.set_ylabel("Commune / Arrondissement", fontsize=12)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.0%}'))
    
    return plot_to_base64(plt)

def creer_graph_taux_elec(df_agg):
    """(Req c) Taux moyen de vélos électriques par communes"""
    print("Génération graphique (c) Taux élec moyen...")
    if df_agg.empty: return ""
    
    data = df_agg.nlargest(30, 'capacity').sort_values('taux_elec_moyen', ascending=False)
    
    plt.figure(figsize=(10, 8))
    ax = sns.barplot(
        data=data,
        x="taux_elec_moyen",
        y="nom_arrondissement_communes",
        palette="coolwarm"
    )
    ax.set_title("Part des vélos électriques parmi les vélos disponibles (Top 30 Communes)", fontsize=16)
    ax.set_xlabel("Taux de vélos électriques (Élec / Total Vélos)", fontsize=12)
    ax.set_ylabel("Commune / Arrondissement", fontsize=12)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.0%}'))
    
    return plot_to_base64(plt)

def creer_graph_indicateur_libre(df_agg):
    """(Req d) Indicateur libre : Score de diversité (mix 50/50)"""
    print("Génération graphique (d) Score diversité...")
    if df_agg.empty: return ""

    data = df_agg.nlargest(30, 'capacity').sort_values('score_diversite', ascending=False)
    
    plt.figure(figsize=(10, 8))
    ax = sns.barplot(
        data=data,
        x="score_diversite",
        y="nom_arrondissement_communes",
        palette="crest"
    )
    ax.set_title("Score de diversité du mix (100% = 50% élec / 50% méca) (Top 30 Communes)", fontsize=16)
    ax.set_xlabel("Score de diversité (0=100% élec/méca, 1=50/50)", fontsize=12)
    ax.set_ylabel("Commune / Arrondissement", fontsize=12)
    ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'{x:.0%}'))
    
    return plot_to_base64(plt)

# --- PARTIE 5 : RAPPORT HTML (MODIFIÉ POUR CONTRÔLE CARTE) ---

def creer_rapport(map_html_file, graphs_base64, total_stats, df_agg):
    """
    Génère le rapport HTML final avec une liste déroulante pour choisir une commune
    ET centrer la carte.
    """
    
    report_file = "rapport_complet_velib.html"
    
    # Renommer les colonnes de df_agg pour la liste déroulante
    df_communes = df_agg.rename(columns={
        'nom_arrondissement_communes': 'Commune / Arrondissement',
        'nb_stations': 'Nombre de Stations',
        'ebike': 'Vélos Électriques',
        'mechanical': 'Vélos Mécaniques'
        # 'lat_moyen' et 'lon_moyen' sont gardés avec leur nom pour le JSON
    })
    
    # Préparer les données JSON pour JavaScript (inclut maintenant lat/lon)
    # Note: df_communes contient 'lat_moyen' et 'lon_moyen' de df_agg
    communes_data = df_communes.to_dict('records')
    communes_json = json.dumps(communes_data, ensure_ascii=False)
    
    # Liste des communes pour le dropdown
    communes_list = sorted(df_communes['Commune / Arrondissement'].unique())
    options_html = "".join([f'<option value="{c}">{c}</option>' for c in communes_list])

    contenu = f"""
    <html>
    <head>
        <meta charset='utf-8'>
        <title>Rapport Vélib' Complet</title>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 0; padding: 0; background: #f9f9f9; }}
            .container {{ max-width: 1200px; margin: 20px auto; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }}
            h1 {{ color: #2C3E50; border-bottom: 3px solid #3498DB; padding-bottom: 10px; }}
            h2 {{ color: #34495E; margin-top: 40px; border-bottom: 1px solid #eee; padding-bottom: 5px; }}
            .info-box {{ background: #E8F8F5; padding: 15px; border-left: 5px solid #1ABC9C; margin: 20px 0; border-radius: 5px; font-size: 1.1em; line-height: 1.6; }}
            p {{ line-height: 1.6; color: #555; }}
            iframe {{ 
                width: 100%; height: 600px; border: 1px solid #ddd; 
                border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                margin-top: 10px;
            }}
            img {{ 
                width: 90%; height: auto; display: block; margin: 20px auto;
                border: 1px solid #ddd; border-radius: 8px;
            }}
            
            /* Style pour le sélecteur de commune */
            .commune-selector {{
                margin: 30px 0;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 8px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }}
            
            .commune-selector label {{
                font-weight: bold;
                font-size: 1.1em;
                color: #2C3E50;
                margin-right: 15px;
            }}
            
            .commune-selector select {{
                padding: 10px 15px;
                font-size: 1em;
                border: 2px solid #3498DB;
                border-radius: 5px;
                background: white;
                cursor: pointer;
                min-width: 300px;
            }}
            
            .commune-selector select:hover {{
                border-color: #2980B9;
            }}
            
            /* Style pour la carte d'information de la commune */
            .commune-info {{
                display: none;
                margin-top: 20px;
                padding: 20px;
                background: white;
                border: 2px solid #3498DB;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }}
            
            .commune-info.active {{
                display: block;
                animation: fadeIn 0.3s;
            }}
            
            @keyframes fadeIn {{
                from {{ opacity: 0; transform: translateY(-10px); }}
                to {{ opacity: 1; transform: translateY(0); }}
            }}
            
            .stat-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
                margin-top: 15px;
            }}
            
            .stat-card {{
                padding: 15px;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border-radius: 8px;
                text-align: center;
            }}
            
            .stat-card.green {{
                background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            }}
            
            .stat-card.orange {{
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            }}
            
            .stat-card.blue {{
                background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            }}
            
            .stat-label {{
                font-size: 0.9em;
                opacity: 0.9;
                margin-bottom: 5px;
            }}
            
            .stat-value {{
                font-size: 2em;
                font-weight: bold;
            }}
        </style>

        <script>
            const communesData = {communes_json};
            
            function afficherCommune() {{
                const select = document.getElementById('communeSelect');
                const commune = select.value;
                const infoDiv = document.getElementById('communeInfo');
                
                // 1. Récupérer l'iframe
                const mapIframe = document.getElementById('map_iframe');

                if (!commune) {{
                    infoDiv.classList.remove('active');
                    // 2. Réinitialiser la carte si on désélectionne
                    try {{
                        if (mapIframe && mapIframe.contentWindow && typeof mapIframe.contentWindow.setMapView === 'function') {{
                            mapIframe.contentWindow.setMapView(48.8566, 2.3522, 11.5); // Coords par défaut
                        }}
                    }} catch (e) {{
                        console.warn("Impossible de réinitialiser la vue de la carte.", e);
                    }}
                    return;
                }}
                
                // 3. Trouver les données (y compris lat/lon)
                const data = communesData.find(c => c['Commune / Arrondissement'] === commune);
                
                if (data) {{
                    // Met à jour les champs (stats)
                    document.getElementById('communeNom').textContent = commune;
                    document.getElementById('nbStations').textContent = data['Nombre de Stations'];
                    document.getElementById('velosElec').textContent = data['Vélos Électriques'];
                    document.getElementById('velosMeca').textContent = data['Vélos Mécaniques'];
                    document.getElementById('totalVelos').textContent = 
                        data['Vélos Électriques'] + data['Vélos Mécaniques'];
                    
                    infoDiv.classList.add('active');

                    // 4. Centrer la carte sur la commune !
                    if (data.lat_moyen && data.lon_moyen) {{
                        try {{
                            // On appelle la fonction 'setMapView' qui est DANS l'iframe
                            if (mapIframe && mapIframe.contentWindow && typeof mapIframe.contentWindow.setMapView === 'function') {{
                                mapIframe.contentWindow.setMapView(data.lat_moyen, data.lon_moyen, 14); // Zoom 14
                            }}
                        }} catch (e) {{
                            console.error("Erreur: La fonction setMapView n'a pas pu être appelée dans l'iframe.", e);
                            console.warn("Assurez-vous d'exécuter cela depuis un serveur web (python -m http.server) si vous avez des problèmes de Cross-Origin.");
                        }}
                    }}
                }}
            }}
        </script>
        </head>
    <body>
    <div class="container">
        <h1>📊 Rapport d'Analyse Vélib' Complet</h1>
        
        <div class="info-box">
            Cette analyse est basée sur les données en temps réel de <b>{total_stats['stations']:,}</b> stations Vélib'.<br>
            <b>Total vélos électriques disponibles :</b> {total_stats['ebike']:,}<br>
            <b>Total vélos mécaniques disponibles :</b> {total_stats['mechanical']:,}
        </div>
        
        <h2>🏙️ Informations par Commune</h2>
        <div class="commune-selector">
            <label for="communeSelect">Choisissez une commune pour centrer la carte :</label>
            <select id="communeSelect" onchange="afficherCommune()">
                <option value="">-- Sélectionnez une commune --</option>
                {options_html}
            </select>
            
            <div id="communeInfo" class="commune-info">
                <h3 id="communeNom" style="margin-top:0; color:#3498DB;"></h3>
                <div class="stat-grid">
                    <div class="stat-card blue">
                        <div class="stat-label">Nombre de Stations</div>
                        <div class="stat-value" id="nbStations">-</div>
                    </div>
                    <div class="stat-card green">
                        <div class="stat-label">⚡ Vélos Électriques</div>
                        <div class="stat-value" id="velosElec">-</div>
                    </div>
                    <div class="stat-card orange">
                        <div class="stat-label">🔧 Vélos Mécaniques</div>
                        <div class="stat-value" id="velosMeca">-</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">🚲 Total Vélos Disponibles</div>
                        <div class="stat-value" id="totalVelos">-</div>
                    </div>
                </div>
            </div>
        </div>
        
        <h2>(a) Carte interactive de toutes les stations</h2>
        <p>Utilisez la <b>liste déroulante en haut à droite de la carte</b> pour afficher/masquer les communes. <b>Survolez un point</b> pour le nom et la dispo, ou <b>cliquez</b> pour les détails complets.</p>
    """
    
    if map_html_file:
        # --- MODIFICATION ICI : Ajout d'un ID à l'iframe ---
        contenu += f"<iframe id='map_iframe' src='{os.path.basename(map_html_file)}'></iframe>"
    else:
        contenu += "<p style='color:red;'><i>La carte n'a pas pu être générée.</i></p>"

    # Ajout de vos graphiques (par commune)
    contenu += f"""
        <h2>(b) Taux de disponibilité moyen (Toutes communes)</h2>
        <p>Comparaison du ratio <code>(vélos disponibles / capacité totale)</code> pour les 30 communes ayant le meilleur taux.</p>
        <img src="{graphs_base64['dispo']}" alt="Graphique Taux Disponibilité">
        
        <h2>(c) Part des vélos électriques (Toutes communes)</h2>
        <p>Comparaison du ratio <code>(vélos électriques / vélos disponibles)</code> pour les 30 communes ayant le plus de capacité.</p>
        <img src="{graphs_base64['elec']}" alt="Graphique Taux Électriques">
        
        <h2>(d) Indicateur libre : Score de diversité (Toutes communes)</h2>
        <p>Ce score mesure l'équilibre du mix de vélos (100% = parfait 50/50 élec/méca ; 0% = 100% d'un seul type). Calculé pour les 30 communes avec le plus de capacité.</p>
        <img src="{graphs_base64['diversite']}" alt="Graphique Score Diversité">
    """

    contenu += "</div></body></html>"
    
    with open(report_file, "w", encoding="utf-8") as f: 
        f.write(contenu)
    
    try:
        webbrowser.open_new_tab(f"file://{os.path.realpath(report_file)}")
        print(f"\n✅ Rapport complet généré : {report_file}")
    except Exception as e:
        print(f"Impossible d'ouvrir le navigateur. Ouvrez le fichier manuellement: {report_file}\nErreur: {e}")

# --- MAIN : Exécution du script (MODIFIÉ) ---
if __name__ == "__main__":
    
    # 1. Charger TOUTES les données
    df = get_all_stations_fast()
    
    if df.empty:
        exit("Aucune donnée n'a été récupérée. Arrêt du script.")

    # 2. Nettoyer les données
    df = analyser_et_supprimer_doublons(df)

    # 3. Calculer les scores (pour la carte)
    df = calculer_score_equilibre(df)
    
    # 4. NOUVEAU: Calculer les stats globales (pour le rapport)
    total_stats = {
        "stations": len(df),
        "ebike": int(df['ebike'].sum()),
        "mechanical": int(df['mechanical'].sum())
    }
    
    # 5. Générer la Carte (a)
    map_file = creer_carte_clusters_communes(df) # Appelle la fonction modifiée
    
    # 6. NOUVEAU: Préparer les données pour les graphiques (b, c, d) ET LE TABLEAU
    print("Préparation des données agrégées pour les graphiques...")
    
    # --- MODIFICATION ICI ---
    # Ajout de lat_moyen et lon_moyen pour centrer la carte
    df_agg = df.groupby('nom_arrondissement_communes').agg(
        nb_stations=pd.NamedAgg(column='stationcode', aggfunc='count'), # Pour le tableau/dropdown
        capacity=('capacity', 'sum'),
        numbikesavailable=('numbikesavailable', 'sum'),
        ebike=('ebike', 'sum'),
        mechanical=('mechanical', 'sum'), # Pour le tableau/dropdown
        lat_moyen=pd.NamedAgg(column='lat', aggfunc='mean'), # <-- AJOUT
        lon_moyen=pd.NamedAgg(column='lon', aggfunc='mean')  # <-- AJOUT
    ).reset_index()
    # --- FIN DE LA MODIFICATION ---

    # Calcul des indicateurs agrégés (pour les graphiques)
    # Protection contre la division par zéro
    df_agg['taux_dispo_moyen'] = (
        df_agg['numbikesavailable'] / df_agg['capacity'].replace(0, np.nan)
    ).fillna(0)
    df_agg['taux_elec_moyen'] = (
        df_agg['ebike'] / df_agg['numbikesavailable'].replace(0, np.nan)
    ).fillna(0.5) # 0.5 (neutre) si pas de vélos dispo
    df_agg['score_diversite'] = (1 - abs(df_agg['taux_elec_moyen'] - 0.5) * 2).clip(0, 1)

    # 7. Générer les Graphes (b, c, d)
    graphs_base64_paths = {
        "dispo": creer_graph_dispo_moyen(df_agg),
        "elec": creer_graph_taux_elec(df_agg),
        "diversite": creer_graph_indicateur_libre(df_agg)
    }

    # 8. NOUVEAU: Générer le rapport final (avec les nouvelles données)
    # On passe df_agg qui contient maintenant lat/lon
    creer_rapport(map_file, graphs_base64_paths, total_stats, df_agg) # Appelle la fonction modifiée